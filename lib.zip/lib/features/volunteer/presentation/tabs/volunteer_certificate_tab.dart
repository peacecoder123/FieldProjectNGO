import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class VolunteerCertificateTab extends ConsumerWidget {
  const VolunteerCertificateTab({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.construction_rounded, size: 48, color: Color(0xFF94A3B8)),
          const SizedBox(height: 12),
          Text('VolunteerCertificateTab', style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}