import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:ngo_volunteer_management/core/widgets/app_shell.dart';
import 'package:ngo_volunteer_management/features/volunteer/presentation/tabs/volunteer_tasks_tab.dart';
import 'package:ngo_volunteer_management/features/volunteer/presentation/tabs/volunteer_meetings_tab.dart';
import 'package:ngo_volunteer_management/features/volunteer/presentation/tabs/volunteer_certificate_tab.dart';
import 'package:ngo_volunteer_management/features/volunteer/presentation/tabs/volunteer_joining_letter_tab.dart';

class VolunteerDashboardScreen extends ConsumerStatefulWidget {
  const VolunteerDashboardScreen({super.key});

  @override
  ConsumerState<VolunteerDashboardScreen> createState() =>
      _VolunteerDashboardState();
}

class _VolunteerDashboardState
    extends ConsumerState<VolunteerDashboardScreen> {
  String _activeTab = 'tasks';

  static const List<NavItem> _navItems = [
    NavItem(id: 'tasks',         label: 'My Tasks',          icon: Icons.check_box_outlined),
    NavItem(id: 'meetings',      label: 'Minutes of Meeting', icon: Icons.calendar_today_rounded),
    NavItem(id: 'certificate',   label: 'Certificate',        icon: Icons.workspace_premium_rounded),
    NavItem(id: 'joining-letter', label: 'Joining Letter',   icon: Icons.mail_outline_rounded),
  ];

  Widget _buildTab() => switch (_activeTab) {
    'tasks'          => const VolunteerTasksTab(),
    'meetings'       => const VolunteerMeetingsTab(),
    'certificate'    => const VolunteerCertificateTab(),
    'joining-letter' => const VolunteerJoiningLetterTab(),
    _                => const VolunteerTasksTab(),
  };

  @override
  Widget build(BuildContext context) {
    return AppShell(
      navItems:    _navItems,
      activeTab:   _activeTab,
      onTabChange: (id) => setState(() => _activeTab = id),
      body:        _buildTab(),
    );
  }
}