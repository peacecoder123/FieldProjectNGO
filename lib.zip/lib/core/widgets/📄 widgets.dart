// Core widget barrel — import this single file to access all shared widgets.
export 'app_avatar.dart';
export 'app_badge.dart';
export 'app_card.dart';
export 'app_modal.dart';
export 'app_shell.dart';
export 'section_header.dart';
export 'stat_card.dart';